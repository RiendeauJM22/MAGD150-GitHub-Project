
function setup() {
  createCanvas(500, 500);
}

function draw() {
background(150)
  angleMode(DEGREES);
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / 2, height / 2);
  push();
  rotate(a);
  ellipse(2, 5, 50, 50);
  pop();
  angleMode(RADIANS);
  rotate(a);
  ellipse(-40, -5, 10, 10);
  angleMode(DEGREES); 
  let c = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / 40, height / 5);
  push();
  rotate(c);
  rect(-90, 5, 100, 100);
  pop();
  angleMode(RADIANS);
  rotate(c);
  ellipse(-10, 5, 100, 100);
  ellipse(30, 20, 50, 50);
  scale(0.5, 1.3);
}