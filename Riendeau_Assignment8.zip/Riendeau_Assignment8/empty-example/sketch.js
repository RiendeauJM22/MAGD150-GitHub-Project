
var img1;
var img2;


function preload() {

	img1 = loadImage("chihuahua.jpg");
	img2 = loadImage("Cutedog.jpg");


}

function setup () {

	createCanvas(650, 500);
	

}

function draw () {
	

	image(img1, -50, 0);

	image(img1, 130, 0, 120, 60);

	image(img2, 300, 100, 240, 120);

	image(img1, 0, 0, mouseX * 2, mouseY * 2);
	textSize(32);

	fill(0,102,153)
	stroke(50)
	textSize(24);
	textFont('arial');
	text('Mans Best Friend', 12, 30);
	textFont('lobster');
	text('Mans Best Friend', 50, 60);
	text('Mans Best Friend', 100, 90);


	
}