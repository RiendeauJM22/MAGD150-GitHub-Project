let vid;
function setup() {
  noCanvas();

  vid = createVideo(
    ['assets/EASports.mp4', 'assets/EASports.ogv', 'assets/EASports.webm'],
    vidLoad
  );

  vid.size(300, 300);
}

// This function is called when the video loads
function vidLoad() {
  vid.loop();
  vid.volume(50);
}